package edu.upc.dsa;

import org.glassfish.grizzly.http.server.HttpServer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

public class Covid19Test {
    private HttpServer server;
    private WebTarget target;
    public Covid19Manager cm;
    @Before
    public void setUp() throws Exception {
        // start the server
        server = Main.startServer();
        // create the client
        Client c = ClientBuilder.newClient();

        //c.configuration().enable(new org.glassfish.jersey.media.json.JsonJaxbFeature());

        target = c.target(Main.BASE_URI);

        cm = Covid19ManagerImpl.getInstance();

        cm.addLab("1","CAP1");
        cm.addLab("2","CAP2");
        cm.addLab("3","Hospital");
        cm.addUser("1","Javier","Salmeron Rodriguez","A");
        cm.addUser("2","Toni","Oller Arcas","B");
        cm.addUser("3","Jaun","Lopez Rubio","C");
        cm.addMuestra("1","clinico1","1","21/11/2020","1");
        cm.addMuestra("2","clinico2","2","21/11/2020","2");
        cm.addMuestra("3","clinico3","3","21/11/2020","2");

    }
    @After
    public void tearDown() throws Exception {
        server.stop();
    }

    //Lab pruebas
    @Test
    public void addlab(){
        cm.addLab("extra","CAPextra");
    }
    @Test
    public void addmaxlab()throws Exception{
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");
        cm.addLab("extra","CAPextra");


    }
    //Lab pruebas


    //User pruebas
    @Test
    public void adduser(){
        cm.addUser("Extra","B","C","A");
    }
    //User pruebas
    //Add muestras
    @Test
    public void addmuestra(){
        cm.addMuestra("extra","extra","1","21/11/2020","1");
    }
    @Test
    public void personaerronia(){
        cm.addMuestra("extra","extra","5","21/11/2020","1");
    }
    @Test
    public void laberroneo(){
        cm.addMuestra("extra","extra","1","21/11/2020","6");
    }
    //Add muestras

    //Procesar
    @Test
    public void rularmuestras(){
        cm.procesarMuestra("1","positivo","cerradito en casa crack");
    }
    @Test
    public void rularmuestrasnolab(){
        cm.procesarMuestra("fallo","positivo","cerradito en casa crack");
    }
    //Procesar

    //Listar muestras
    @Test
    public void listarmuestras(){
        cm.listarMuestrasProcesadas("1");
    }
    @Test
    public void listarmuestrasnoid(){
        cm.listarMuestrasProcesadas("fallo");
    }
    //Listar muestras
}
