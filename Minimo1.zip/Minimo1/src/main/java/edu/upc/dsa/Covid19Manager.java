package edu.upc.dsa;

import java.util.List;
import edu.upc.dsa.models.Muestra;

public interface Covid19Manager {
    public int addUser(String id, String nombre, String apellidos, String saludlvl); //Crear usr
    public int addMuestra(String id, String clinico, String personaid, String fecha, String idlab);
    public int procesarMuestra(String idlab,String resultado, String comentario); //quitar una de la que coincida y generar informe
    public List<Muestra> listarMuestrasProcesadas(String idUsr);//buscar usuario y devolver la lista
    public int addLab(String id, String nombre);
}
