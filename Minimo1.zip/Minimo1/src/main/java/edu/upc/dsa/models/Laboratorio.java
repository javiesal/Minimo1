package edu.upc.dsa.models;

import java.util.Queue;

public class Laboratorio {
    String id;
    String nombre;
    Queue<Muestra> muestrasenespera;

    public Laboratorio(){

    }

    public Laboratorio(String id, String nombre){
        this.id = id;
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Queue<Muestra> getMuestrasenespera() {
        return muestrasenespera;
    }

    public void addMuestrasenespera(Muestra muestra) {
        this.muestrasenespera.offer(muestra);
    }
}
