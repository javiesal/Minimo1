package edu.upc.dsa.services;


import edu.upc.dsa.Covid19Manager;
import edu.upc.dsa.Covid19ManagerImpl;
import edu.upc.dsa.TracksManager;
import edu.upc.dsa.TracksManagerImpl;
import edu.upc.dsa.models.Laboratorio;
import edu.upc.dsa.models.Muestra;
import edu.upc.dsa.models.Track;
import edu.upc.dsa.models.Usuario;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.ws.rs.*;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

@Api(value = "/cov2", description = "Endpoint to Covid19 Service")
@Path("/cov2")
public class Covid19Service {
    private Covid19Manager cm;
    public Covid19Service(){
        this.cm = Covid19ManagerImpl.getInstance();
        /*cm.addLab("1","CAP1");
        cm.addLab("2","CAP2");
        cm.addLab("3","Hospital");
        cm.addUser("1","Javier","Salmeron Rodriguez","A");
        cm.addUser("2","Toni","Oller Arcas","B");
        cm.addUser("3","Jaun","Lopez Rubio","C");
        cm.addMuestra("1","clinico1","1","21/11/2020","1");
        cm.addMuestra("2","clinico2","2","21/11/2020","2");
        cm.addMuestra("3","clinico3","3","21/11/2020","2");*/
    }


    @POST
    @ApiOperation(value = "Crear nuevo User", notes = "Fill the fields")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Usuario creado", response= Usuario.class),
    })

    @Path("/newuser")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response newUsr(Usuario usuario) {
        cm.addUser(usuario.getId(), usuario.getNombre(), usuario.getApellidos(), usuario.getSaludlvl());
        return Response.status(201).entity(usuario).build();
    }



    @POST
    @ApiOperation(value = "Crear nuevo Lab", notes = "Fill the fields")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Lab creado", response= Laboratorio.class),
            @ApiResponse(code = 500, message = "Maximo numero de labs")

    })

    @Path("/newlab")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response newLab(Laboratorio lab) {
        int x = cm.addLab(lab.getId(),lab.getNombre());
        if (x == 0) {
            return Response.status(201).entity(lab).build();
        }
        else{
            return Response.status(500).entity(lab).build();
        }
    }

    @POST
    @ApiOperation(value = "Crear nueva Muestra", notes = "Fill the fields")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Muestra creada", response= Muestra.class),
            @ApiResponse(code = 404, message = "Usuario no encontrado"),
            @ApiResponse(code = 502, message = "Maximo numero de labs")

    })

    @Path("/newmuestra")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response newMuestra(Muestra muestra) {
        int x = cm.addMuestra(muestra.getId(), muestra.getClinico(), muestra.getPersonaid(), muestra.getFecha(), muestra.getIdlab());
        if (x == 0) {
            return Response.status(201).entity(muestra).build();
        }
        else if(x==1){
            return Response.status(502).entity(muestra).build();
        }
        else{
            return Response.status(404).entity(muestra).build();
        }
    }

    @GET
    @ApiOperation(value = "Obtener muestras procesadas", notes = "Fill the fields")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Listado", response = Muestra.class, responseContainer="List"),
            @ApiResponse(code = 400, message = "Error")
    })
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMuestras(@PathParam("id") String usrid) {

        List<Muestra> muestras = this.cm.listarMuestrasProcesadas(usrid);

        GenericEntity<List<Muestra>> entity = new GenericEntity<List<Muestra>>(muestras) {};

        if(muestras != null){
            return Response.status(201).entity(entity).build()  ;

        }else{
            return Response.status(400).entity(entity).build()  ;
        }

    }

    @PUT
    @ApiOperation(value = "Actualizar Lab y generar informe", notes = "Fill the fields")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successful"),
            @ApiResponse(code = 404, message = "Data not found")
    })
    @Path("/{id}/{result}/{commit}")
    public Response updateLab(@PathParam("id") String labid,@PathParam("result") String result,@PathParam("commit") String commit) {

        int x = this.cm.procesarMuestra(labid,result,commit);
        if (x == 0){
            return Response.status(201).build();
        }else{
            return Response.status(404).build();

        }
    }

}
