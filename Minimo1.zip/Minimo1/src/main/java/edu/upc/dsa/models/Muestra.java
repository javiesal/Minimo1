package edu.upc.dsa.models;

public class Muestra {
    String id;
    String clinico;
    String personaid;
    String fecha;
    String idlab;
    Informe informe;
    public Muestra(){

    }

    public Muestra(String id, String clinico, String personaid, String fecha, String idlab){
        this.id = id;
        this.clinico = clinico;
        this.personaid = personaid;
        this.fecha = fecha;
        this.idlab = idlab;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClinico() {
        return clinico;
    }

    public void setClinico(String clinico) {
        this.clinico = clinico;
    }

    public String getPersonaid() {
        return personaid;
    }

    public void setPersonaid(String personaid) {
        this.personaid = personaid;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getIdlab() {
        return idlab;
    }

    public void setIdlab(String idlab) {
        this.idlab = idlab;
    }

    public Informe getInforme(){
        return this.informe;
    }

    public void setInforme (Informe informe){
        this.informe = informe;
    }
}
