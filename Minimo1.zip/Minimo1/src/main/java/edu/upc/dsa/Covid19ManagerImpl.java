package edu.upc.dsa;

import edu.upc.dsa.models.Informe;
import edu.upc.dsa.models.Laboratorio;
import edu.upc.dsa.models.Muestra;
import edu.upc.dsa.models.Usuario;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.List;

public class Covid19ManagerImpl implements Covid19Manager {
    private static Covid19Manager instance;
    private HashMap<String, Usuario> listausuarios;
    private Laboratorio[] laboratorios;
    private int numLabs;
    private int max;
    final static Logger logger = Logger.getLogger(Covid19ManagerImpl.class.getName());

    private Covid19ManagerImpl(){
        this.listausuarios= new HashMap<String,Usuario>();
        this.numLabs = 0;
        this.max = 10;
        this.laboratorios = new Laboratorio[max];
    }

    public static Covid19Manager getInstance() {
        if (instance==null) instance = new Covid19ManagerImpl();
        return instance;
    }

    @Override
    public int addUser(String id, String nombre, String apellidos, String saludlvl) {
        logger.debug("Creando usuario");
        Usuario nuevousuario = new Usuario(id, nombre,apellidos,saludlvl);
        listausuarios.put(id,nuevousuario);
        logger.info("Usuario creado con id: " + id);
        return 0;

    }

    @Override
    public int addMuestra(String id, String clinico, String personaid, String fecha, String idlab) {
        logger.info("Creando muestra");
        Usuario usuariomuestra = listausuarios.get(personaid);
        if(usuariomuestra!=null) {
            Muestra newmuestra = new Muestra(id, clinico, personaid, fecha, idlab);
            logger.info("Muestra creada con id: " + id);
            int i = 0;
            boolean Found = false;
            while ((i < numLabs) && (!Found)) {
                if (laboratorios[i].getId().equals(idlab)) {
                    Found = true;
                } else {
                    i++;
                }


            }
            if (Found) {
                logger.info("ERROR, AQUI PETA NO SE PORQUE");
                laboratorios[i].addMuestrasenespera(newmuestra);
                logger.info("Muestra con id " + id + " añadida a cola del laboratorio con id " + idlab);
                return 0;

            } else {
                logger.info("Laboratorio no encontrado. Muestra rechazada");
                return 1;
            }
        }
        else{
            logger.error("Usuario no encontrado. Muestra rechazada");
            return 2;
        }
    }

    @Override
    public int procesarMuestra(String idlab,String resultado, String comentario) {
        logger.debug("Buscando laboratorio en el que se ubica la muestra");
        int i = 0;
        boolean Found = false;
        while ((i<numLabs)&&(!Found)){
            if (laboratorios[i].getId().equals(idlab)){
                Found = true;
            }
            else{
                i++;
            }
        }
        if(Found){
            logger.debug("Laboratorio con id "+idlab+" encontrado. Procesando una muestra.");
            Informe nuevoinforme = new Informe(resultado, comentario);
            Muestra muestraproc = laboratorios[i].getMuestrasenespera().poll();
            muestraproc.setInforme(nuevoinforme);
            logger.debug("Informe añadido a la muestra");
            Usuario usuariomuestra = listausuarios.get(muestraproc.getId());
            if (usuariomuestra != null){
                usuariomuestra.addmuestras(muestraproc);
                logger.info("Informe añadido y muestra en el usuario");
                return 0;
            }else{
                logger.error("Usuario no existente. Muestra rechazada");
                return 1;
            }
        }else{
            logger.error("Laboratorio no encontrado. Muestra no procesada");
            return 2;
        }
    }

    @Override
    public List<Muestra> listarMuestrasProcesadas(String idUsr) {
        List<Muestra> muestras;
        Usuario usuariomuestras = listausuarios.get(idUsr);
        if (usuariomuestras != null){
            muestras = usuariomuestras.getUsermuestras();
            logger.info("Muestras mostradas");
            return muestras;
        }else{
            logger.error("Usuario no existente. Cancelado");
            return null;
        }
    }

    @Override
    public int addLab(String id, String nombre) {
        logger.debug("Creando laboratorio en BBDD");
        Laboratorio newlab = new Laboratorio(id, nombre);
        logger.debug("Laboratorio creado con id: " + id);
        if (this.numLabs<this.max){
            this.laboratorios[this.numLabs] = newlab;
            this.numLabs ++;
            logger.info("Laboratorio añadido con id: "+id);
            return 0;
        }else{
            logger.error("Máximo numero de laboratorios, no se añade");
            return 1;
        }
    }
}
