package edu.upc.dsa.models;

import java.util.LinkedList;

public class Usuario {
    String id;
    String nombre;
    String apellidos;
    String saludlvl; //A,B,C,D
    LinkedList<Muestra> Usermuestras;

    public Usuario(){

    }

    public Usuario(String id, String nombre, String apellidos, String saludlvl){
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.saludlvl = saludlvl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getSaludlvl() {
        return saludlvl;
    }

    public void setSaludlvl(String saludlvl) {
        this.saludlvl = saludlvl;
    }

    public LinkedList<Muestra> getUsermuestras() {
        return Usermuestras;
    }

    public void addmuestras(Muestra muestra) {
        Usermuestras.add(muestra);//Maybe temporal?
    }
}
