package edu.upc.dsa.models;

public class Informe {
    String resultado;
    String comentatio;

    public Informe(){}
    public Informe(String resultado, String comentario){
        this.resultado = resultado;
        this.comentatio = comentario;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getComentatio() {
        return comentatio;
    }

    public void setComentatio(String comentatio) {
        this.comentatio = comentatio;
    }
}
